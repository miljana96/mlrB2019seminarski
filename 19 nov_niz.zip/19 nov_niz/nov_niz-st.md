---
title: Нов низ
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:    miljanamarkovic # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN  # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

За задати низ од $n$ целих бројева креирати и исписати нови низ чији се елементи добијају као збирови првог и последњег елемента унетог низа, затим другог и претпоследњег...
Подразумева се да је $n$ парно.
Пример: 
Aко је задат низ: 4, 8, 6, 2, 1, 9, нов низ је: 13, 9, 8.

## Улаз

Са стандардног улаза учитава се из прве линије природан број $n$ (паран).
Из наредних $n$ линија учитавају се елементи низа (цели бројеви).

## Излаз

На стандардни излаз у једној линији исписати елемнте новог низа, раздвојене размаком.

## Пример

### Улаз

~~~
22
113
-158
-506
965
-834
35
-725
685
-639
62
-622
-211
979
744
710
17
920
-732
545
437
679
847
~~~

### Излаз

~~~
960 521 -69 1510 -1566 955 -708 1395 105 1041 -833 
~~~
