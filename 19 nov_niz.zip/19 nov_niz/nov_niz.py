n = int(input())
niz = []
nov_niz = []
duzina_novog_niza = n // 2

for i in range(n):
	niz.append(int(input()))
for i in range(duzina_novog_niza):
	nov_niz.append(niz[i] + niz[n - i - 1])
	print(nov_niz[i], end =" ")
print()