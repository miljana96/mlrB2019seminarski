using System;

class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine()); // n parno
		int[] niz = new int[n];
		int duzina_novog_niza = n / 2;
		int[] nov_niz = new int[duzina_novog_niza];
		
		for(int i = 0; i < n; i++)
			niz[i] = int.Parse(Console.ReadLine());
		for(int i = 0; i < duzina_novog_niza; i++){
			nov_niz[i] = niz[i] + niz[n - i - 1]; 
			Console.Write(nov_niz[i]+" ");
		}
		Console.WriteLine();
    }
}
