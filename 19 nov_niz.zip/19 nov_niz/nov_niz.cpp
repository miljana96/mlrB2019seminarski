#include <iostream>

using namespace std;

int main() {
   
	int n; // n parno
	cin >> n;
	int* niz = new int[n];
	int duzina_novog_niza = n / 2;
	int* nov_niz = new int[duzina_novog_niza];
	
	for(int i = 0; i < n; i++)
		cin >> niz[i];
	for(int i = 0; i < duzina_novog_niza; i++){
		nov_niz[i] = niz[i] + niz[n - i - 1]; 
		cout << nov_niz[i] << " ";
	}
	cout << endl;
	
	delete[] niz;
	delete[] nov_niz;
	
   return 0;
}