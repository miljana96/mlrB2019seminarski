#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "nov_niz";

void gen_test(int i, ostream &tin) {
	
	int n = random_value(1,20) * 2;
	tin << n << endl;
	for(int i = 0; i < n; i++)
		tin << random_value(-1000, 1000) << endl;
	
}
