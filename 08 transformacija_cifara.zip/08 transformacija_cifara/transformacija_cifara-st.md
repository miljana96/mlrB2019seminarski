---
title: Трансформација цифара
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:  miljanamarkovic   # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Написати програм који унети природан број трансформише тако што сваку парну цифру увећа за један, а сваку непарну цифру умањи за један. 
Исписати број који се добије након извршене трансформације.

## Улаз
Са стандардног улаза учитава се природан број. 
Напомена: Уколико се у броју појави цифра нула, сматрати да је треба повећати за један. Уколико се унесе само 0, нов број је 0. 

## Излаз

На стандардни излаз исписати број који се добије након трансформације.

## Пример

### Улаз

~~~
153
~~~

### Излаз

~~~
42
~~~
