using System;

public class Program
{
	
    public static void Main(string[] args)
    {
        int broj = int.Parse(Console.ReadLine()); 
		int cifra;
		int nov_broj = 0;
		int stepen = 0;
		
		while(broj != 0)
		{
			cifra = broj % 10;
			
			if(cifra % 2 == 0){
				cifra++;
			}else{
				cifra--;
			}
			
			nov_broj += cifra * (int)Math.Pow(10, stepen);
			stepen++;
			broj = broj / 10;
		}
		Console.WriteLine(nov_broj);
    }
}
