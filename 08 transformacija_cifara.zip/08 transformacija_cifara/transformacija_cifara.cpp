#include <iostream>
#include <cmath>
using namespace std;

int main() {
	int broj; 
	
	cin >> broj;
	
	int cifra;
	int nov_broj = 0;
	int stepen = 0;
	
	while(broj != 0)
	{
		cifra = broj % 10;
		
		if(cifra % 2 == 0){
			cifra++;
		}else{
			cifra--;
		}
		
		nov_broj += cifra * pow(10, stepen);
		stepen++;
		broj = broj / 10;
	}
	
	cout << nov_broj;
   
   return 0;
}