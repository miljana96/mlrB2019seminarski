broj = int(input())  
nov_broj = 0
stepen = 0

while broj != 0:
    cifra = broj % 10
    if cifra % 2 == 0: 
        cifra = cifra + 1
    else:
        cifra = cifra - 1
    nov_broj = nov_broj + cifra * pow(10, stepen)
    stepen = stepen + 1
    broj = broj // 10

print(nov_broj)

