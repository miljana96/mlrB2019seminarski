import sys
import math
def prost(duzina):
	for i in range(2, int(math.sqrt(duzina)) + 1):
			if duzina % i == 0:
				return False			
	return True


for linija in sys.stdin:
	if prost(len(linija) - 1):
	    print("niska je prosta!")
	    linija = linija[:len(linija)-1] + str(len(linija) - 1)
	    print(linija)
	else: 
		print("niska je slozena!")