#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "prosta_i_slozena_niska";

void gen_test(int i, ostream &tin) {
	
	if(i == 1)
		tin << "da" << endl << "ne" << endl << "slozena niska!" << endl;
	else{
		for(int i = 0; i < 50; i += 5){
			tin << "niska" << i << endl;
		}
	}
}
