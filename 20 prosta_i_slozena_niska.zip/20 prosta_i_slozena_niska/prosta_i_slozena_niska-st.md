---
title: Проста и сложена ниска
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:     miljanamarkovic# vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Написати програм који проверава да ли је унета ниска проста или сложена. 
Ниска је проста уколико је њена дужина прост број, у супротном је сложена. 
Уколико је ниска проста, извршити трансформацију, тако што се на сам крај ниске додаје карактер, који представља дужину ниске.


## Улаз

Са стандардног улаза учитавају се ниске, свака у посебној линији, све до краја улаза.

## Излаз

За сваку ниску проверити да ли је њена дужина прост број и у зависности од тога, исписати одговарајуће поруке.
Уколико је дужина ниске прост број, исписати поруку "ниска је проста!" као и трансформисану ниску.
Уколико је дужина ниске сложен број, исписати поруку "ниска је сложена!". 
## Пример

### Улаз

~~~
da
ne
slozena niska!
~~~

### Излаз

~~~
niska je prosta!
da2
niska je prosta!
ne2
niska je slozena!
~~~
