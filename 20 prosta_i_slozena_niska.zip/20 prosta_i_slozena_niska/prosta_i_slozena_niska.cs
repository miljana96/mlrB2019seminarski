using System;

class Program
{  	static bool prost(int duzina){
		for(int i = 2; i <= Math.Sqrt(duzina); i++){
			if(duzina % i == 0)
				return false;			
		}
		return true;
	}
   
	static void Main(string[] args){
		string s;
		while((s = Console.ReadLine()) != null){
				if(prost(s.Length))
				{   Console.WriteLine("niska je prosta!");
					s += s.Length; 
					Console.WriteLine(s);
				}else 
					Console.WriteLine("niska je slozena!");
		}
	   
    }
}