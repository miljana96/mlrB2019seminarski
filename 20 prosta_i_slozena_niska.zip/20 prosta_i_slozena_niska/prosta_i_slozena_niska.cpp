#include <iostream>
#include <string>
#include <cmath>
using namespace std;

bool prost(int duzina){
		for(int i = 2; i <= sqrt(duzina); i++){
			if(duzina % i == 0)
				return false;			
		}
		return true;
}
  
int main() {
	  
	string s;
	while(getline(cin, s)){
		if(prost(s.length())){   
			cout << "niska je prosta!" << endl;
			cout << s << s.length()<< endl;
		}else 
			cout << "niska je slozena!" << endl;
	}
		
   return 0;
}