#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "nindza_kornjace";

void gen_test(int i, ostream &tin) {
	
	if (i == 1)
		tin << "n" << endl;
	if (i == 2)
		tin << "l" << endl;
	if (i == 3)
		tin << "c" << endl;
	if (i == 4)
		tin << "p" << endl;
	if (i == 5)
		tin << "N" << endl;
	if (i == 6)
		tin << "4" << endl;
	if (i == 7)
		tin << "/" << endl;
	if (i == 8)
		tin << "f" << endl;
	if (i == 9)
		tin << "v" << endl;
	if (i == 10)
		tin << " " << endl;
}
