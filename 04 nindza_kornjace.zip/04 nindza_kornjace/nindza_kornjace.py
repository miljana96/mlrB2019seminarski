maska = input() 
if maska == 'n':
	print("Mikelandjelo")
elif maska == 'p':
	print("Leonardo")
elif maska == 'l':
	print("Donatelo")
elif maska == 'c':
	print("Rafaelo")
else:
	print("Nema kornjace sa unetom maskom!")
