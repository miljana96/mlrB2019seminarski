---
title: Нинџа корњаче
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:     miljanamarkovic# vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN  # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Свака нинџа корњача носи маску одређене боје. 
У зависности од унетог почетног слова боје маске, исписати о којој нинџа корњачи је реч.
Уколико је боја маске наранџаста, нинџа корњача се зове Микеланђело, уколико је боја маске плава,
нинџа корњача се зове Леонардо, уколико је боја љубичаста (за почетно слово узети слово л), 
нинџа корњача се зове Донатело, а уколико је боја црвена, нинџа корњача се зове Рафаело. 
У случају да боја не одговара ни једној нинџа корњачи, исписати поруку "Nema kornjace sa unetom maskom!". 


## Улаз

Са стандардог улаза се учитава почетно слово маске, у једној линији.

## Излаз

На стандардни излаз исписати име нинџа корњаче, или уколико почетно слово боје маске не 
одговара ни једној корњачи, исписати поруку "Nema kornjace sa unetom maskom!".

## Пример

### Улаз

~~~
n
~~~

### Излаз

~~~
Mikelandjelo
~~~
