using System;

class Program
{
    static void Main(string[] args)
    {
        char maska = char.Parse(Console.ReadLine());
		switch(maska){
			case 'n':
				Console.WriteLine("Mikelandjelo");
				break;
			case 'p':
				Console.WriteLine("Leonardo");
				break;
			case 'l':
				Console.WriteLine("Donatelo");
				break;
			case 'c':
				Console.WriteLine("Rafaelo");
				break;
			default:
				Console.WriteLine("Nema kornjace sa unetom maskom!");
				break;
		}   
    }
}
