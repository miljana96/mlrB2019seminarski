#include <iostream>

using namespace std;

int main() {
   char maska;
   cin >> maska;
		switch(maska){
			case 'n':
				cout << "Mikelandjelo";
				break;
			case 'p':
				cout << "Leonardo";
				break;
			case 'l':
				cout << "Donatelo";
				break;
			case 'c':
				cout << "Rafaelo";
				break;
			default:
				cout << "Nema kornjace sa unetom maskom!";
				break;
		}   
   return 0;
}