using System;

class Program
{
    static void Main(string[] args)
    {
		int a = int.Parse(Console.ReadLine());
		int b = int.Parse(Console.ReadLine());
		double ha = double.Parse(Console.ReadLine());
		double hb;
		hb = (a * ha) / (double)b;
		Console.WriteLine(hb.ToString("0.00"));
		
    }
}
