#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "paralelogram";

void gen_test(int i, ostream &tin) {
	
   int a, b;
   double ha;
   a = random_value(1,100);
   b = random_value(1, 100);
   ha = random_value(1,100);
   tin << a << endl << b << endl << ha << endl;
   
}
