---
title: Паралелограм
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner: miljanamarkovic     # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Дате су странице $a$ и $b$ паралелограма, као и висина која одговара страници $а$. Одредити висину која одговара страници $b$.


## Улаз

Са стандардног улаза учитавају се подаци о страницама троугла (цео број између 1 и 100), као и податак о висини која одговара страници $а$ паралелограма(реалан број).

## Излаз

На стандардни излаз исписати висину паралелограма која одговара страници $b$ (реалан број заокружен на 2 децимале).

## Пример

### Улаз

~~~
95
68
34
~~~

### Излаз

~~~
47.50
~~~
