a = int(input())
b = int(input())
ha = float(input())
hb = (a * ha)/ b
print("%.2f" %hb)



