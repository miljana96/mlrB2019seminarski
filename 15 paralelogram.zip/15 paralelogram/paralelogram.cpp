#include <iostream>
#include <iomanip>
using namespace std;

int main() {
   int a, b;
   double ha;
   double hb;
   cin >> a >> b >> ha;
   hb = (a * ha) / b;
   cout << fixed << showpoint << setprecision(2) << hb << endl;
   return 0;
}