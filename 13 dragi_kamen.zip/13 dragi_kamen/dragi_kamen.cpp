#include <iostream>
#include <string>
#include <sstream>
using namespace std;

int main() {
		string s;// dd.mm.gg
		cin >> s;
		stringstream broj(s.substr(3,2));
		int mesec;
		broj >> mesec;
	
		switch(mesec){
			case 1: 
				cout << "granat" << endl;
				break;
			case 2: 
				cout << "ametist" << endl;
				break;
			case 3: 
				cout << "akvamarin" << endl;
				break;
			case 4:
				cout << "dijamant" << endl;
				break;
			case 5:
				cout << "smaragd" << endl;
				break;
			case 6: 
				cout << "biser" << endl;
				break;
			case 7:
				cout << "rubin" << endl;
				break;
			case 8:
				cout << "peridot" << endl;
			    break;
			case 9:
				cout << "safir" << endl;
				break;
			case 10:
				cout << "opal" << endl;
				break;
			case 11:
				cout << "topaz" << endl;
				break;
			case 12:
				cout << "tirkiz" << endl;
				break;
		}
   return 0;
}