#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "dragi_kamen";

void gen_test(int i, ostream &tin) {
	
	int dan = random_value(1,31);
	int mesec = random_value(1,12);
	int godina = random_value(1900,2500);
	string s;
	if(mesec == 2 && (godina % 4 == 0 && godina % 100 != 0) || (godina % 400 == 0))
		dan = random_value(1,29);
	else if(mesec == 2)
		dan = random_value(1,28);
	if(mesec <= 9 && dan <= 9)
		tin << "0" << dan << "." << "0" << mesec << "." << godina << "." << endl;
	else if(mesec > 9 && dan > 9)
		tin << dan << "." << mesec << "." << godina << "." << endl;
	else if(mesec > 9 && dan <= 9)
		tin << "0" << dan << "." << mesec << "." << godina << "." << endl;
	else if(mesec <= 9 && dan > 9)
		tin << dan << "." << "0" << mesec << "." << godina << "." << endl;
}
