using System;

public class Program{
    
    public static void Main(){
        
		string s = Console.ReadLine();// dd.mm.gg
		string mm = s[3]+""+s[4];
		int mesec = int.Parse(mm);

		switch(mesec){
			case 1: 
				Console.WriteLine("granat");
				break;
			case 2: 
				Console.WriteLine("ametist");
				break;
			case 3: 
				Console.WriteLine("akvamarin");
				break;
			case 4:
				Console.WriteLine("dijamant");
				break;
			case 5:
				Console.WriteLine("smaragd");
				break;
			case 6: 
				Console.WriteLine("biser");
				break;
			case 7:
				Console.WriteLine("rubin");
				break;
			case 8:
				Console.WriteLine("peridot");
			    break;
			case 9:
				Console.WriteLine("safir");
				break;
			case 10:
				Console.WriteLine("opal");
				break;
			case 11:
				Console.WriteLine("topaz");
				break;
			case 12:
				Console.WriteLine("tirkiz");
				break;
		}
	}
}