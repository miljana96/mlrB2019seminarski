---
title: Драги камен
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:    miljanamarkovic # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---
За сваки месец у години карактеристичан је један драги камен. 
На основу датума рођења који се уноси у формату дд.мм.гггг. исписати назив одговарајућег драгог камена.


## Улаз

Са стандардног улаза учитава се датум у формату дд.мм.гггг., из једне линије.

## Излаз

На стандардни излаз, у зависности од месеца, исписати одговарајућу поруку.

## Пример

### Улаз

~~~
25.11.1996.
~~

### Излаз

~~~
topaz
~~~
