s = input()  
mm = s[3]+""+s[4];
mesec = int(mm);

if mesec == 1:
	print("granat")
elif mesec == 2:
	print("ametist")
elif mesec == 3:
	print("akvamarin")
elif mesec == 4:
	print("dijamant")
elif mesec == 5:
	print("smaragd")
elif mesec == 6:
	print("biser")
elif mesec == 7:
	print("rubin")
elif mesec == 8:
	print("peridot")
elif mesec == 9:
	print("safir")
elif mesec == 10:
	print("opal")
elif mesec == 11:
	print("topaz")
else:
	print("tirkiz");
