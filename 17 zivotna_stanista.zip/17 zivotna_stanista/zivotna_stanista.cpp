#include <iostream>
#include <string>
using namespace std;

int main() {
	
	int staniste; 
	string prirodna_kultivisana;
	cin >> staniste >> prirodna_kultivisana;
	
	if(staniste == 1){
		if(prirodna_kultivisana == "prirodna"){
			cout << "sume: listopadne, cetinarske" << endl;
			cout << "travnate oblasti: livade, pasnjaci" << endl;
		}else if(prirodna_kultivisana == "kultivisana"){
			cout << "njive, povrtnjaci, vocnjaci, vinogradi, parkovi" << endl;
		}else{
			cout << "Podaci nisu uneti ispravno!" << endl;
		}
	}else if(staniste == 2){
		if(prirodna_kultivisana == "prirodna"){
			cout << "tekuce vode: potoci, reke" << endl;
			cout << "stajace vode: bare, jezera" << endl;
		}else if(prirodna_kultivisana == "kultivisana"){
			cout << "vestacka jezera, ribnjaci" << endl;
		}else{
			cout << "Podaci nisu uneti ispravno!" << endl;
		}
	}else{
		cout << "Podaci nisu uneti ispravno!" << endl;
	} 
   
   return 0;
}