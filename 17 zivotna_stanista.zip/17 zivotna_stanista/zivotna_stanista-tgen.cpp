#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "zivotna_stanista";

void gen_test(int i, ostream &tin) {
	
	if(i == 1)
		tin << 1 << endl << "prirodna" << endl;
	else if(i == 2)
		tin << 1 << endl << "kultivisana" << endl;
	else if(i == 3)
		tin << 2 << endl << "prirodna" << endl;
	else if(i == 4)
		tin << 2 << endl << "kultivisana" << endl;
	else if(i == 5)
		tin << random_value(3,10) << endl << "prirodna" << endl;
	else if(i == 6)
		tin << random_value(3, 10) << endl << "kultivisana" << endl;
	else if(i == 7)
		tin << 1 << endl << "staniste" << endl;
	else if(i == 8)
		tin << 2 << endl << "staniste" << endl;
	else{
		tin << random_value(3, 200) << endl << "staniste" << endl;
	}
	
}
