using System;

class Program
{
    static void Main(string[] args)
    {
        int staniste = int.Parse(Console.ReadLine()); 
		string prirodna_kultivisana = Console.ReadLine();

		if(staniste == 1){
			if(prirodna_kultivisana == "prirodna"){
				Console.WriteLine("sume: listopadne, cetinarske");
				Console.WriteLine("travnate oblasti: livade, pasnjaci");
			}else if(prirodna_kultivisana == "kultivisana"){
				Console.WriteLine("njive, povrtnjaci, vocnjaci, vinogradi, parkovi");
			}else{
				Console.WriteLine("Podaci nisu uneti ispravno!");
			}
		}else if(staniste == 2){
			if(prirodna_kultivisana == "prirodna"){
				Console.WriteLine("tekuce vode: potoci, reke");
				Console.WriteLine("stajace vode: bare, jezera");
			}else if(prirodna_kultivisana == "kultivisana"){
				Console.WriteLine("vestacka jezera, ribnjaci");
			}else{
				Console.WriteLine("Podaci nisu uneti ispravno!");
			}
		}else{
			Console.WriteLine("Podaci nisu uneti ispravno!");
		}
			
    }
}
