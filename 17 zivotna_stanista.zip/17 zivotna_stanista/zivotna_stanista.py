staniste = int(input())
prirodna_kultivisana = input() 
	
if staniste == 1:
	if prirodna_kultivisana == "prirodna":
		print("sume: listopadne, cetinarske")
		print("travnate oblasti: livade, pasnjaci")
	elif prirodna_kultivisana == "kultivisana":
		print("njive, povrtnjaci, vocnjaci, vinogradi, parkovi")
	else:
	     print("Podaci nisu uneti ispravno!")
elif staniste == 2:
	if prirodna_kultivisana == "prirodna":
		print("tekuce vode: potoci, reke") 
		print("stajace vode: bare, jezera")
	elif prirodna_kultivisana == "kultivisana":
		print("vestacka jezera, ribnjaci")
	else:
	     print("Podaci nisu uneti ispravno!")
else:
    print("Podaci nisu uneti ispravno!")


