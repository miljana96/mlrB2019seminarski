import math
def pretrazi(rastojanje, poluprecnici):
	pocetak = 0
	kraj = len(poluprecnici) - 1
	prvi_veci_pozicija = -1
	while pocetak < kraj:
		sredina = (pocetak + kraj)//2
		if poluprecnici[sredina] > rastojanje:
			kraj = sredina
			prvi_veci_pozicija = sredina
		else:
			pocetak = pocetak + 1
			if pocetak == kraj and prvi_veci_pozicija == -1:
				sredina = (pocetak + kraj)//2
				if poluprecnici[sredina] > rastojanje:
					prvi_veci_pozicija = sredina
					break;
	return prvi_veci_pozicija

def rastojanje(x, y):
	return math.sqrt(x * x + y * y)

m = int(input())
poluprecnici = []
poeni = []

for i in range(m):
	niz = [int(i) for i in input().split()]
	poluprecnici.append(niz[0])
	poeni.append(niz[1])
	
n = int(input())  
ukupno_poena = 0.0

for i in range(n):
	niz = [int(i) for i in input().split()]
	x = niz[0]
	y = niz[1]
	r = rastojanje(x,y)
	krug = pretrazi(r, poluprecnici)
	if krug != -1:
		ukupno_poena += poeni[krug]
	

print("%.2f" %ukupno_poena)


