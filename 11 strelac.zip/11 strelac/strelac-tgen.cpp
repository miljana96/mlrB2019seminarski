#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "strelac";

void gen_test(int i, ostream &tin) {
	int m = random_value(1,10);
	tin << m << endl;
	int poluprecnik = 3;
	double poen = 10.0;
	for(int i = 0; i < m; i++)
	{	poluprecnik += 2;
		poen += 5.0;	
		tin << poluprecnik << " " << poen << endl;
	}	
	int n = random_value(1, 5);
	tin << n << endl;
	double x, y;
	for(int i = 0; i < n; i++)
	{	x = random_value(1,15)*1.0;
		y = random_value(1,15)*1.0;	
		tin << x << " " << y << endl;
	}	

}
