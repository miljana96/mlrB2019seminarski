#include <iostream>
#include <cmath>
#include <array>
#include <iomanip>
using namespace std;

int pretrazi(double rastojanje, int* poluprecnici, int m){
	int pocetak = 0;
	int kraj =  m - 1;
	int prvi_veci_pozicija = -1;
	while(pocetak < kraj){
		int sredina = (pocetak + kraj)/2;
		if(poluprecnici[sredina] > rastojanje){
			kraj = sredina;
			prvi_veci_pozicija = sredina;
		}else{
			pocetak = pocetak + 1;
			if(pocetak == kraj && prvi_veci_pozicija == -1){
				sredina = (pocetak + kraj)/2;
				if(poluprecnici[sredina] > rastojanje){
					prvi_veci_pozicija = sredina;
					break;
				}
			}
		
		}
	}
	return prvi_veci_pozicija;
}

double rastojanje(double x, double y){
	return sqrt(x * x + y * y);
}


int main() {
   
	int m;
	cin >> m;
	int* poluprecnici = new int[m];
	double* poeni = new double[m];
	for(int i = 0; i < m; i++){
		cin >> poluprecnici[i] >> poeni[i];
		
	}
   
	int n;
	cin >> n;
	int krug;
	double ukupno_poena = 0.0;
 
	for(int i = 0; i < n; i++){
		double x, y, r;
		cin >> x >> y;
		r = rastojanje(x,y);
		krug = pretrazi(r, poluprecnici, m);
		
		if(krug != -1){
			ukupno_poena += poeni[krug];
		}
	}
  
   cout << fixed << showpoint << setprecision(2) << ukupno_poena << endl; 
   return 0;
}