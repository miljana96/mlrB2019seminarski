using System;

class Program
{ 
	static int pretrazi(double rastojanje, int[] poluprecnici){
		int pocetak = 0;
		int kraj = poluprecnici.Length - 1;
		int prvi_veci_pozicija = -1;
		while(pocetak < kraj){
			int sredina = (pocetak + kraj)/2;
			if(poluprecnici[sredina] > rastojanje){
				kraj = sredina;
				prvi_veci_pozicija = sredina;
			}else{
				pocetak = pocetak + 1;
				if(pocetak == kraj && prvi_veci_pozicija == -1){
					sredina = (pocetak + kraj)/2;
					if(poluprecnici[sredina] > rastojanje){
						prvi_veci_pozicija = sredina;
						break;
					}
				}
			}
		}
		return prvi_veci_pozicija;
	}
	
	static double rastojanje(double x, double y){
		return Math.Sqrt(x * x + y * y);
	}
	
	static void Main(string[] args){
		int m = int.Parse(Console.ReadLine()); // m poluprecnika
		int[] poluprecnici = new int[m];
		double[] poeni = new double[m];
	 
		for(int i = 0; i < m; i++){
			string[] niz = Console.ReadLine().Split();
			poluprecnici[i] = int.Parse(niz[0]);
			poeni[i] = double.Parse(niz[1]);
		}
		
		int n = int.Parse(Console.ReadLine());  // n tacaka
		int krug;
		double ukupno_poena = 0.0;
	 
		for(int i = 0; i < n; i++){
			string[] niz = Console.ReadLine().Split();
			double x = double.Parse(niz[0]);
			double y = double.Parse(niz[1]);
			double r = rastojanje(x,y);
			krug = pretrazi(r, poluprecnici);
		
			if(krug != -1){
				ukupno_poena += poeni[krug];
			}
		}
	  
	  Console.WriteLine(ukupno_poena.ToString("0.00"));  
	}
}
