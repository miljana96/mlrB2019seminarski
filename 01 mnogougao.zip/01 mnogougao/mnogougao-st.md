---
title: Многоугао
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:   miljanamarkovic  # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba da je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Уколико је познат број дијагонала из једног темена многоугла, израчунати број страна многоугла, 
као и укупан број дијагонала датог многоугла.

## Улаз

Са стандардног улаза се учитава једна линија у којој се налази један природан број 
(између 0 и 100000) који представља број дијагонала многоугла из једног темена.

## Излаз


На стандардни излаз исписати број страна многоугла (природан број), као и укупан број дијагонала (природан број), 
и то сваки у посебном реду.

## Пример

### Улаз

~~~
0
~~~

### Излаз

~~~
3
0
~~~
