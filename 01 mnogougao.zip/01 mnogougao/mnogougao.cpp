#include <iostream>

using namespace std;

int main() {
	int dn, n, Dn;
	cin >> dn;
	n = dn + 3;
	Dn = (n * (n - 3))/2;
	cout << n << endl << Dn << endl; 	
   
   return 0;
}