dn = int(input())
n = dn + 3 
Dn = (n * (n - 3))//2
print(n)
print(Dn)