using System;

class Program
{
    static void Main(string[] args)
    {   // ucitava se broj dijagonala mnogougla iz jednog temena
        int dn = int.Parse(Console.ReadLine());      
		int n, Dn;
		// dn = n-3 => n = dn + 3
		n = dn + 3;
		
		Dn = (n * (n - 3))/2;
		Console.WriteLine(n);
		Console.WriteLine(Dn);
		
	}
}
