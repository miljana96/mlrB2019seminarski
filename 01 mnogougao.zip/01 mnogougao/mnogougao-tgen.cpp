#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "mnogougao";

void gen_test(int i, ostream &tin) {
	if (i ==  1)
		tin << 0 << endl;
	else if (i == 2)
		tin << 1 << endl;
	else if (i == 3)
		tin << 5 << endl;
	else if (i == 4)
		tin << 100 << endl;
	else if (i == 5)
		tin << 1000 << endl;
	else if (i == 6)
		tin << 250 << endl;
	else if (i == 7)
		tin << random_value(1, 100) << endl;
	else if (i == 8)
		tin << random_value(50, 10000) << endl;
	else if (i == 9)
		tin << random_value(0, 4000) << endl;
	else if (i == 10)
		tin << random_value(2000, 9000)<< endl;
	
}
