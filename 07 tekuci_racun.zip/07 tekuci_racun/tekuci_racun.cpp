#include <iostream>

using namespace std;

int main(){
  
	int prethodno_stanje;
	cin >> prethodno_stanje;
    
	int transakcija;
	int iznos;
	int saldo = prethodno_stanje;
	int max_isplata = 0;
		
	while(cin >> iznos >> transakcija) 
	{   
		if(transakcija == 1)
			saldo += iznos;
		else{
			if(max_isplata < iznos)
				max_isplata = iznos;
			saldo -= iznos;
		}
	}
	
	cout << saldo << endl;
	if(max_isplata != 0)
		cout << max_isplata << endl;  
	else
		cout << "nije bilo isplata" << endl;

   return 0;
}
