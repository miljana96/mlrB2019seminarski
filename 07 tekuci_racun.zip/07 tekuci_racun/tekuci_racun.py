import sys
prethodno_stanje = int(input())
saldo = prethodno_stanje
max_isplata = 0
	
for linija in sys.stdin:
    niz = linija.split()
    iznos = int(niz[0])
    transakcija = int(niz[1])
    if transakcija == 1:
        saldo += iznos
    else:
        if max_isplata < iznos:
            max_isplata = iznos
        saldo -= iznos

print(saldo)

if max_isplata != 0:
	print(max_isplata)
else:
	print("nije bilo isplata")



