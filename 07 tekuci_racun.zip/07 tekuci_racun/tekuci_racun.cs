using System;

class Program
{
    static void Main(string[] args)
    {
        int prethodno_stanje=int.Parse(Console.ReadLine());
        string s;
		int transakcija;
		int iznos;
		int saldo = prethodno_stanje;
		int max_isplata = 0;
		
		while((s = Console.ReadLine())!= null) 
		{
			string[] niz = s.Split();
			iznos =	int.Parse(niz[0]);
			transakcija = int.Parse(niz[1]);
			if(transakcija == 1)
				saldo += iznos;
			else{
				if(max_isplata < iznos)
					max_isplata = iznos;
				saldo -= iznos;
			}
		}
		
		Console.WriteLine(saldo);
		if(max_isplata != 0)
			Console.WriteLine(max_isplata);  
		else
			Console.WriteLine("nije bilo isplata");
    }
}
