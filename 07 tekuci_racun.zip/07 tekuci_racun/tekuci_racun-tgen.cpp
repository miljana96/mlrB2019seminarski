#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "tekuci_racun";

void gen_test(int i, ostream &tin) {
	if (i == 1)
		tin << "50000" << endl << "2000 1" << endl << "3000 2" << endl << "1000 1" << endl; 	
	else if (i == 2)
		tin << "100000" << endl << "90000 2" << endl << "15000 2" << endl;
	else if (i == 3)
		tin << "15000" << endl << "10000 1" << endl << "20000 1" << endl;
	else if (i == 4)
		tin << "1000" << endl << "1000 2" << endl << "5000 2" << endl << "1500 2" << endl << "7000 2" << endl << "80000 1" << endl; 
 	else
	{	int prethodno_stanje=random_value(2000, 500000);
		int transakcija=1;
		int iznos;
		tin << prethodno_stanje << endl;
		for(int j = 0;j < 30;j++){
			iznos = random_value(500,20000);
			if(transakcija == 1)
				transakcija++;
			else 
				transakcija--;
			tin << iznos << " " << transakcija << endl;
		}
	}
 	
}	
