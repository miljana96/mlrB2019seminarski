#include <iostream>

using namespace std;

int main() {
	
	int n;
	cin >> n;
	int* niz = new int[n];
	
	for(int i = 0; i < n; i++)
			cin >> niz[i];
	int zbir;
	cin >> zbir;
	int zbir_parcijalno;
	bool indikator = false;
		
	for(int pocetak = 0; pocetak < n; pocetak++)
	{	zbir_parcijalno = 0;
		for(int kraj = pocetak; kraj < n; kraj++){
			zbir_parcijalno += niz[kraj];
			if(zbir_parcijalno == zbir){
				cout << pocetak <<  " " << kraj << endl;
				indikator = true;
			}
		}
				
	}
		
	if(!indikator)
		cout << "Ne postoje delovi niza koji daju zbir " << zbir << endl;

	delete[] niz;
   return 0;
}