#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "parcijalni_niz";

void gen_test(int i, ostream &tin) {
	
	int n = random_value(1,50);
	tin << n << endl;
	
	for(int i = 0; i < n; i++)
	{
		tin << random_value(1,100) << endl;
	}
	
	tin << random_value(1,50) << endl;
	
}
