using System;

class Program
{
    static void Main(string[] args)
    {
		int n = int.Parse(Console.ReadLine());
		int[] niz = new int[n];
		
		for(int i = 0; i < n; i++)
			niz[i] = int.Parse(Console.ReadLine());
		int zbir = int.Parse(Console.ReadLine());
		
		int zbir_parcijalno;
		bool indikator = false;
		
		for(int pocetak = 0; pocetak < n; pocetak++)
		{	zbir_parcijalno = 0;
			for(int kraj = pocetak; kraj < n; kraj++){
				zbir_parcijalno += niz[kraj];
				if(zbir_parcijalno == zbir){
					Console.WriteLine(pocetak + " " + kraj);
					indikator = true;
				}
			}
				
		}
		
		if(!indikator)
			Console.WriteLine("Ne postoje delovi niza koji daju zbir " + zbir);
			
    }
}
