n = int(input())
niz = []

for i in range(n):
	niz.append(int(input()))

zbir = int(input())

indikator = False

for pocetak in range(n):
	zbir_parcijalno = 0
	for kraj in range(pocetak, n):
	    zbir_parcijalno += niz[kraj]
	    if zbir_parcijalno == zbir:
	        print(str(pocetak) + " " + str(kraj))
	        indikator = True
	
if(indikator == False):
	print("Ne postoje delovi niza koji daju zbir " + str(zbir))
	
