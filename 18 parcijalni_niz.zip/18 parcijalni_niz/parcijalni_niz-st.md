---
title: Парцијални низ
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:    miljanamarkovic # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Написати програм којим се проверава да ли у унетом низу постоје елементи који дају одређени збир.
Провера креће од почетка низа, и проверава се део по део низа.

## Улаз

Са стандардног улаза учитава се природан број $$ (између 1 и 50). Из наредних $$ линија учитавају се елементи низа (цели бројеви).
Након учитаних елмената низа, учитава се цео број који представља збир (број између 1 и 50).

## Излаз

На стандардни излаз исписати позицију почетног елемента, као и позицију крањег елемента низа.
Почетни елемент низа је онај од кога почиње збир, а крајњи елемент је онај с којим се завршава збир.
На пример: У низу од 5 елемената: 1 2 3 4 5, проверавамо да ли постоје елементи који дају збир 6 (почевши од првог па све до краја).
1 + 2 + 3 = 6, дакле почетна позиција је 0, а последња позиција је 2.
Уколико не постоји група елемената која одговара унетом збиру, исписати поруку: "Ne postoje delovi niza koji daju zbir 6".
## Пример

### Улаз

~~~
5
1
2
3
4
5
6
~~~

### Излаз

~~~
0 2
~~~
