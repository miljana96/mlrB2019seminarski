using System;

class Program
{
    static void Main(string[] args)
    {   // ucitava se poluprecnik kruznice
        int poluprecnik = int.Parse(Console.ReadLine());   
		// ucitava se centralni ugao
		int alfa = int.Parse(Console.ReadLine());
		
		double kruzni_luk = (poluprecnik * alfa * Math.PI)/180.0;
		
		
		Console.WriteLine(kruzni_luk.ToString("0.00"));
	
	}
}

