---
title: Кружни лук
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:    miljanamarkovic 
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: IZRADA   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Израчунати дужину кружног лука, ако су познати централни угао и полупречник кружнице.

## Улаз

Са стандардног улаза се учитавају две линије. У првој се налази 
цео број (између 1 и 1000) који представљају полупречник круга,
а у другој се налази централни угао изражен у степенима (између 1 и 360).


## Излаз

На стандардни излаз исписати дужину кружног лука. Добијену вредност заокружити на 2 децимале.

## Пример

### Улаз

~~~
15
75
~~~

### Излаз

~~~
19,63
~~~
