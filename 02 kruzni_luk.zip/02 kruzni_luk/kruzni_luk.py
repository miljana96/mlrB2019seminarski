import math
poluprecnik = int(input())
ugao = int(input())
kruzni_luk = (poluprecnik * ugao * math.pi)/180.0;
print("%.2f" %kruzni_luk)