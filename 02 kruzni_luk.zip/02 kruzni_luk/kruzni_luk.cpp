#define _USE_MATH_DEFINES
#include <iostream>
#include <cmath>   /* ukljucujemo zbog M_PI */
#include <iomanip> /* ukjlucujemo zbog setprecision */


using namespace std;

int main() {
   int poluprecnik, ugao;
   double kruzni_luk;
   cin >> poluprecnik >> ugao;
	
	kruzni_luk = (poluprecnik * ugao * M_PI)/180.0;
	cout << fixed << showpoint << setprecision(2) << kruzni_luk << endl; 
   return 0;
}
