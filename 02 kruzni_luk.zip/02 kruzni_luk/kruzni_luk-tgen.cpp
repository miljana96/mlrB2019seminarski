#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "kruzni_luk";

void gen_test(int i, ostream &tin) {
	if (i == 1)
		tin << "15" << endl << "75" << endl;
	else if (i == 2)
		tin << "1000" << endl << "360" << endl;
	else if (i == 3)
		tin << "1" << endl << "1" << endl;
	else if (i == 4)
		tin << "2" << endl << "180" << endl;
	else if (i == 5)
		tin << "40" << endl << "215" << endl;
	else if (i == 6)
		tin << "3" << endl << "2" << endl;
	else if (i == 7)
        tin << "650" << endl << "330" << endl;
	else if (i == 8)
        tin << "20" << endl << "200" << endl;
	else if (i == 9)
        tin << "700" << endl << "30" << endl;
	else if (i == 10)
        tin << "900" << endl << "270" << endl;
 	
		
}
