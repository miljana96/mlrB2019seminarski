using System;

class Program
{
	static bool razlicite_cifre(int broj, int cifra1){
		int indikator = 0;
		
		while(broj != 0){
			int cifra = broj % 10;
			if(cifra == cifra1)
				indikator++;
			broj = broj / 10;
		}
		
		if(indikator > 1)
			return false;
		return true;
	}
	
    static void Main(string[] args)
    {
		int n = int.Parse(Console.ReadLine());
		int cifra;
		int zbir = 0;
		int proizvod = 1;
		bool indikator2 = true;
		if(n == 0){
			Console.WriteLine(0);
			Console.WriteLine(0);
			indikator2 = false;
		}
		
		while(n != 0){
			cifra = n % 10; 
			zbir += cifra;
			proizvod *= cifra;
			bool indikator = razlicite_cifre(n, cifra);
			if(!indikator){
				Console.WriteLine("cifre nisu razlicite");
				indikator2 = false;
				break;
			}
			n = n / 10;
		}
		if (indikator2){
			Console.WriteLine(zbir);
			Console.WriteLine(proizvod);
		}
    }
}
