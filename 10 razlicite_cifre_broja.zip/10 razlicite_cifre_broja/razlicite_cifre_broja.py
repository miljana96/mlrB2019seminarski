def razlicite_cifre(broj, cifra1):
    indikator = 0
    
    while broj != 0:
    	cifra = broj % 10
    	if cifra == cifra1:
    		indikator = indikator + 1
    	broj = broj // 10
    
    if indikator > 1:
    	return False
    
    return True



n = int(input())
zbir = 0
proizvod = 1
indikator2 = True

if n == 0:
	print(0)
	print(0)
	indikator2 = False


while n != 0:
	cifra = n % 10 
	zbir += cifra
	proizvod *= cifra
	indikator = razlicite_cifre(n, cifra)
	if indikator == False:
		print("cifre nisu razlicite")
		indikator2 = False
		break
	n = n // 10

if indikator2 == True:
	print(zbir)
	print(proizvod)
