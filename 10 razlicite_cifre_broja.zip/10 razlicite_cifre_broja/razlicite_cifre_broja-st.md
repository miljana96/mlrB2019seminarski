---
title: Различите цифре броја
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:     # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: IZRADA   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

За унети број $n$, проверити да ли су му све цифре различите и уколико јесу исписати збир и произовд цифара датог броја $n$.

## Улаз

Са стандардног улаза учитава се природан број. 

## Излаз

На стандардни излаз исисати збир и производ цифара датог броја, а уколико сe нека цифра понавља, исписати поруку "cifre nisu razlicite".

## Пример

### Улаз

~~~
124
~~~

### Излаз

~~~
7
8
~~~
