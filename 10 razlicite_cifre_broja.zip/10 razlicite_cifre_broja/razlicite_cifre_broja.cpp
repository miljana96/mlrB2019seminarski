#include <iostream>

using namespace std;

bool razlicite_cifre(int broj, int cifra1){
	int indikator = 0;
	
	while(broj != 0){
		int cifra = broj % 10;
		if(cifra == cifra1)
			indikator++;
		broj = broj / 10;
	}
	
	if(indikator > 1)
		return false;
	return true;
}

int main() {
	int n;
	cin >> n;
	int cifra;
	int zbir = 0;
	int proizvod = 1;
	bool indikator2 = true;
	
	if(n == 0){
		cout << 0 << endl << 0 << endl;
		indikator2 = false;
	}
	
	while(n != 0){
		cifra = n % 10; 
		zbir += cifra;
		proizvod *= cifra;
		bool indikator = razlicite_cifre(n, cifra);
		if(!indikator){
			cout << "cifre nisu razlicite" << endl;
			indikator2 = false;
			break;
		}
		n = n / 10;
	}
	if (indikator2){
		cout << zbir << endl << proizvod << endl;
	}
   return 0;
}