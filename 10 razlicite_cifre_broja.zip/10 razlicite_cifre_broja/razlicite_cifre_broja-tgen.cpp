#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "razlicite_cifre_broja";

void gen_test(int i, ostream &tin) {
	if (i == 1)
		tin << 0 << endl;
	else if (i == 2)
		tin << 11 << endl;
	else if (i == 3)
		tin << 10 << endl;
	else if (i == 4)
		tin << 102341 << endl;
	else
		tin << random_value(1,1000000) << endl;
}
