using System;

class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine()); 
		if (n % 2 == 0)
			Console.WriteLine("2");
		else 
			Console.WriteLine("3");
    }
}
