---
title: Бојење графа
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:     miljanamarkovic # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navođena izvora
tags: []   # svaki zadatak treba da je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN  # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---


Одредити хроматски број графа чија су темена и ивице, темена и ивице правилног $n$-тоугла. 
Хроматски број графа је најмањи број a, такав да се граф може правилно обојити са а боја. 
Уколико је $n$ парно, граф се може обојити са 2 боје, а уколико је $n$ непарно, може са 3 боје. 
У зависности од унетог $n$, исписати хроматски број графа.

## Улаз

Учитава се број страница правилног $n$-тоугла у једној линији (природан број, између 3 и 1000). 

## Излаз

На стандардни излаз исписати хроматски број графа.

## Пример

### Улаз

~~~
15
~~~

### Излаз

~~~
3
~~~
