#include <iostream>

using namespace std;

int main() {
	int n;
    
	cin >> n;
    
	if (n % 2 == 0)
        cout << "2";
    else
        cout << "3";
        
   return 0;
}