#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "bojenje_grafa";

void gen_test(int i, ostream &tin) {
	if (i == 1)
		tin << "15" << endl;
	else if (i == 2)
		tin << "1000" << endl;
	else if (i == 3)
		tin << "100" << endl;
	else if (i == 4)
		tin << "258" << endl;
	else if (i == 5)
		tin << "3" << endl; 
	else if (i == 6)
		tin << "105" << endl; 
	else if (i == 7)
        tin << "655" << endl;
	else if (i == 8)
        tin << "200" << endl;
	else if (i == 9)
        tin << "515" << endl;
	else if (i == 10)
        tin << "999" << endl;
 	
}
