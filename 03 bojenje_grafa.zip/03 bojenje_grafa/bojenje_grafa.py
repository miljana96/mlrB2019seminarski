n = int(input())
if n % 2 == 0:
	print("2")
else:
	print("3")
