#define _USE_MATH_DEFINES
#include <iostream>
#include <cmath>
using namespace std;

int main() {
	int poluprecnik, izvodnica;
	cin >> poluprecnik >> izvodnica;
	double povrsina, zapremina;
	
	povrsina = poluprecnik * poluprecnik * M_PI + poluprecnik * izvodnica * M_PI;
	
	double visina = sqrt(izvodnica * izvodnica - poluprecnik * poluprecnik);
	
	zapremina = (poluprecnik * poluprecnik * M_PI * visina) / 3.0;
	
	cout << round(povrsina) << " " << round(zapremina) << endl;
   
   return 0;
}