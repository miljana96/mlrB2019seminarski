#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "kupa";

void gen_test(int i, ostream &tin) {
	if(i == 1)
		tin << 3 << endl << 5 << endl;
	else if (i == 2)
		tin << 12 << endl << 13 << endl;
	else if (i == 3)
		tin << 8 << endl << 17 << endl;
	else if (i == 4)
		tin << 60 << endl << 109 << endl;
	else if (i == 5)
		tin << 19 << endl << 181 << endl;
	else
		tin << random_value(1,50) << endl << random_value(50,100) << endl;
}
