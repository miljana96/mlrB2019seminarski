---
title: Купа
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:   miljanamarkovic  # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Израчунати површину и запремину купе, ако су познати полупречник и изводница купе.

## Улаз

Са стандардног улаза учитава се полупречник (природан број између 1 и 50), а затим се учитава изводница купе (природан број мањи од 100).
Сваки податак се налази у посебној линији.
Напомена: изводница купе мора бити већа од полупречника.

## Излаз

На стандардни излаз треба исписати површину и запремину у једној линији (раздвојено размаком), а вредност заокружити на најближи цео број.

## Пример

### Улаз

~~~
3
5
~~~

### Излаз

~~~
75 38
~~~
