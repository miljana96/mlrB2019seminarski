using System;

class Program
{
	static void Main(string[] args)
    {
        int poluprecnik = int.Parse(Console.ReadLine());
		int izvodnica = int.Parse(Console.ReadLine());
		double povrsina, zapremina;
		
		povrsina = poluprecnik * poluprecnik * Math.PI + poluprecnik * izvodnica * Math.PI;
		
		double visina = Math.Sqrt(izvodnica * izvodnica - poluprecnik * poluprecnik);
	   	
		zapremina = (poluprecnik * poluprecnik * Math.PI * visina) / 3.0;
		
		Console.WriteLine(Math.Round(povrsina) +" "+ Math.Round(zapremina));
    }
}
