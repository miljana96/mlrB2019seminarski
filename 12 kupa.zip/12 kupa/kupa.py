import math
poluprecnik = int(input())
izvodnica = int(input())

povrsina = poluprecnik * poluprecnik * math.pi + poluprecnik * izvodnica * math.pi

visina = math.sqrt(izvodnica * izvodnica - poluprecnik * poluprecnik)

zapremina = (poluprecnik * poluprecnik * math.pi * visina) / 3

print(round(povrsina), round(zapremina))
