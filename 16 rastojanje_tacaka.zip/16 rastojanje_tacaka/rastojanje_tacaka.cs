using System;

class Program
{
    static void Main(string[] args)
    {
		int a, b;
		a = int.Parse(Console.ReadLine());
		b = int.Parse(Console.ReadLine());
		int rastojanje = Math.Abs(a - b);
		Console.WriteLine(rastojanje);
    }
}
