---
title: Растојанје тацака
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:     miljanamarkovic# vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Марко је у школи учио растојање тачака на бројевној правој. Хтео је да провери своје знање.
Помози Марку да за унете тачке одреди њихово растојање на бројевној правој.

## Улаз

Са стандардног улаза учитавају се два цела броја (између -10000 и 10000), сваки у посебној линији.

## Излаз

На стандардни излаз исписати растојање на бројевној правој (цео број).

## Пример

### Улаз

~~~
-3157
9448
~~~

### Излаз

~~~
12605
~~~
