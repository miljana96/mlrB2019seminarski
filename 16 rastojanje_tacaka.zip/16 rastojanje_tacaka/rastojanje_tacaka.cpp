#include <iostream>
#include <cmath>
using namespace std;

int main() {
   
	int a , b;
	cin >> a >> b;
	int rastojanje = abs(a-b);
	cout << rastojanje << endl;
   
   return 0;
}