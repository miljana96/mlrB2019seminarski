#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "rastojanje_tacaka";

void gen_test(int i, ostream &tin) {
	int a, b;
	a = random_value(-10000, 10000);
	b = random_value(-10000, 10000);
	tin << a << endl << b << endl;
}
