a = int(input())
b = int(input())
rastojanje = abs(a - b)
print(rastojanje)