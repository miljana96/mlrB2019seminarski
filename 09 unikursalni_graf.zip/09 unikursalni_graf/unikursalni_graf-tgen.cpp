#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "unikursalni_graf";

void gen_test(int i, ostream &tin) {
	int n = random_value(2,200);
	tin << n << endl;
	if (i == 1){
		for(int j = 0; j < n; j++)
		{	int broj = random_value(1,100);
			if (broj % 2 != 0)
				broj++;
			tin << broj << endl;
		}	
	}else{
		for(int j = 0; j < n; j++)
			tin << random_value(1,1000) << endl;
	}
}
