using System;

public class Program
{
   public static void Main(string[] args)
    {
     
	   int n = int.Parse(Console.ReadLine());
	   int indeks_temena;
	   int brojac = 0;
	   
	   for(int i = 0;i < n;i++){
	   		indeks_temena = int.Parse(Console.ReadLine());
		    if(indeks_temena % 2 != 0)
				brojac++;
	   }
	  if(brojac > 2){
	  	  Console.WriteLine("nije unikursalan");
		  Console.WriteLine(brojac);
	  }else{
	  	  Console.WriteLine("jeste unikursalan");
	  }
	   
    }
}