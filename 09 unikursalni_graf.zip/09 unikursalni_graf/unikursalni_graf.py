n = int(input())
brojac = 0

for i in range(n):
    indeks_temena = int(input())
    if indeks_temena % 2 != 0:
        brojac = brojac + 1
if brojac > 2:
	print("nije unikursalan")
	print(brojac)
else:
	print("jeste unikursalan")




