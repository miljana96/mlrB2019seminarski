---
title: Уникурсални граф
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner: miljanamarkovic    # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba da je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN  # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Маја има испит из Очигледне топологије, на коме ће један од задатака бити да провери да ли је граф уникурсалан. 
Граф је уникурсалан ако је повезан и ако су највише 2 темена непарног индекса. 
Маја зна да ће граф на испиту бити повезан, остаје још само да провери да ли су темена парног или непарног индекса. 
Написати програм који помаже Маји да за унетих n темена провери да ли је граф уникурсалан или не, и исписати одговарајућу поруку.

Напомена: индекс темена графа је природан број који представља број ивица из једног темена графа.
## Улаз

Са стандардног улаза учитава се природан број $n$ (број између 2 и 200). Затим се у наредних $n$ линија учитавају индекси сваког темена графа (природан број).

## Излаз

На стандардни излаз исписати поруку "jeste unikursalan", ако је граф уникурсалан, у супротном исписати поруку "nije unikursalan".
Уколико граф није уникурсалан, исписати у линији испод и број темена која су непарног индекса.
## Пример

### Улаз

~~~
5
1
2
7
6
4
~~~

### Излаз

~~~
jeste unikursalan
~~~
