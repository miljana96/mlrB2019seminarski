using System;

class Program
{
    static void Main(string[] args)
    {
		int a, b, c;
		a = int.Parse(Console.ReadLine());
		b = int.Parse(Console.ReadLine());
		c = int.Parse(Console.ReadLine());
		
		int povrsina_prvog, povrsina_drugog, povrsina_treceg;
		
		povrsina_prvog = a * a;
		povrsina_drugog = b * b;
		povrsina_treceg = c * c;
		
		if(povrsina_prvog > povrsina_drugog && povrsina_prvog > povrsina_treceg){	
			Console.WriteLine(povrsina_prvog);
			if(povrsina_prvog == povrsina_drugog + povrsina_treceg)
				Console.WriteLine("trougao je pravougli");
		}else if (povrsina_drugog > povrsina_prvog && povrsina_drugog > povrsina_treceg){
			Console.WriteLine(povrsina_drugog);
			if(povrsina_drugog == povrsina_prvog + povrsina_treceg)
				Console.WriteLine("trougao je pravougli");
		}else{
			Console.WriteLine(povrsina_treceg);
			if(povrsina_treceg == povrsina_prvog + povrsina_drugog)
				Console.WriteLine("trougao je pravougli");
		}
      
    }
}
