#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "Pitagorina_teorema";

void gen_test(int i, ostream &tin) {
	if(i == 1)
		tin << 3 << endl << 4 << endl << 5 << endl;
	else if (i == 2)
		tin << 13 << endl << 5 << endl << 12 << endl;
	else if (i == 3)
		tin << 15 << endl << 8 << endl << 17 << endl;
	else if (i == 4)
		tin << 91 << endl << 60 << endl << 109 << endl;
	else if (i == 5)
		tin << 19 << endl << 181 << endl << 180 << endl;
	else
		tin << random_value(1,100) << endl << random_value(10,50) << endl << random_value(40,200) << endl;
		
}
