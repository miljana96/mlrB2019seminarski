---
title: Питагорина теорема
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:     miljanamarkovic # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN  # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Уносе се три странице троугла: $a$, $b$, $c$. 
Од унетих страница израчунати површине 3 квадрата, чије су редом странице $a$, $b$, $c$.  
Наћи површину квадрата која је највећа и на основу добијених резултата исписати да ли је троугао правоугли.

## Улаз

Са стандардног улаза уносе се три странице троугла: $a$, $b$, $c$ (природни бројеви између 1 и 200), свака страница у посебној линији.  

## Излаз

На стандардни излаз исписати површину оног квадрата чија је површина максимална. Уколико је троугао правоугли исписати поруку: "trougao je pravougli", а у колико није, исписати само максималну површину.


## Пример

### Улаз

~~~
3
4
5
~~~

### Излаз

~~~
25
trougao je pravougli
~~~
