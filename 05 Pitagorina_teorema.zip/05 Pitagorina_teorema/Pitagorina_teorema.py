a = int(input())
b = int(input())
c = int(input())

povrsina_prvog = a * a
povrsina_drugog = b * b
povrsina_treceg = c * c

if povrsina_prvog > povrsina_drugog and povrsina_prvog > povrsina_treceg:	
	print(povrsina_prvog)
	if povrsina_prvog == povrsina_drugog + povrsina_treceg:
		print("trougao je pravougli")
elif povrsina_drugog > povrsina_prvog and povrsina_drugog > povrsina_treceg:
	print(povrsina_drugog)
	if povrsina_drugog == povrsina_prvog + povrsina_treceg:
		print("trougao je pravougli")
else:
	print(povrsina_treceg)
	if povrsina_treceg == povrsina_prvog + povrsina_drugog:
		print("trougao je pravougli")
