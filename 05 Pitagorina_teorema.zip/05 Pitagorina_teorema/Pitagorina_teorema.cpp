#include <iostream>

using namespace std;

int main() {
	int a, b, c;
	cin >> a >> b >> c;
	
	int povrsina_prvog, povrsina_drugog, povrsina_treceg;
	
	povrsina_prvog = a * a;
	povrsina_drugog = b * b;
	povrsina_treceg = c * c;
	
	int max;

	if(povrsina_prvog > povrsina_drugog && povrsina_prvog > povrsina_treceg){	
		max = povrsina_prvog;
		cout << max << endl;
		if(max == povrsina_drugog + povrsina_treceg)
			cout << "trougao je pravougli";
	}else if (povrsina_drugog > povrsina_prvog && povrsina_drugog > povrsina_treceg){
		max = povrsina_drugog;
		cout << max << endl;
		if(max == povrsina_prvog + povrsina_treceg)
			cout << "trougao je pravougli";
	}else{
		max = povrsina_treceg;
		cout << max << endl;
		if(max == povrsina_prvog + povrsina_drugog)
			cout << "trougao je pravougli";
	}
   
   return 0;
}