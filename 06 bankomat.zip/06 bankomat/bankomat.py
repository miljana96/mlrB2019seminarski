pocetni_iznos = int(input())
n = int(input())
saldo = pocetni_iznos
for i in range(0,n):
	iznos = int(input())
	saldo -= iznos
print(saldo)