#include <iostream>

using namespace std;

int main() {
	// ucitavanje ulaznih podataka
	int pocetni_iznos, n;
	cin >> pocetni_iznos >> n;
	// promenljiva saldo sluzi za cuvanje trenutnog stanja u bankomatu
	int saldo = pocetni_iznos; 
	
	for(int i = 0; i < n; i++){
		int iznos;
		cin >> iznos;
		saldo -= iznos;
	}
	
	cout << saldo;
   
   return 0;
}