using System;

class Program
{
    static void Main(string[] args)
    {
        int pocetni_iznos = int.Parse(Console.ReadLine());
		int n = int.Parse(Console.ReadLine());
		int saldo = pocetni_iznos;
		
		for(int i = 0; i < n; i++){
			int iznos = int.Parse(Console.ReadLine());
			saldo -= iznos;
		}
		Console.WriteLine(saldo);
    }
}
