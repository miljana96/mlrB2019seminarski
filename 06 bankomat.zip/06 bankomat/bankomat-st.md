---
title: Банкомат
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner:     miljanamarkovic# vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN  # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Сваког дана n људи подиже новац са банкомата. 
Написати програм који израчунава колико новца остаје на крају дана у банкомату. 
Претпоставити да ће укупан подигнути новац из банкомата бити мањи или једнак од укупног новца, 
којим банкомат располаже на дневном нивоу.
Напомена: Банкомат располаже и апоенима од 1, 2, 5, 10, 20 динара. 

## Улаз

Са стандардног улаза се учитава из прве линије природан број (између 100 000 и 1 000 000 000) који представља износ 
расположивог новца који се налази у банкомату. Из друге линије се учитава природан број n (између 0 и 100)
који представља број људи који подижу новац, а затим у наредних n линија
износи новца који се подижу.

## Излаз

На стандардни излаз исписати колико новца остаје на крају дана у банкомату. 

## Пример

### Улаз

~~~
100 000
5
23 000
17 000
5 000
9 000
11 000
~~~

### Излаз

~~~
35 000
~~~
