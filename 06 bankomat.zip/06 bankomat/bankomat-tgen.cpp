#include "tgen.hpp"

int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "bankomat";

void gen_test(int i, ostream &tin) {
	
	if(i == 1)
		tin << 100000 << endl << 5 << endl << 23000 << endl << 17000 << endl << 5000 << endl << 9000 << endl << 11000;
	else {
		int pocetni_iznos = random_value(1000000, 2000000);
		int n = random_value(0,100);
		tin << pocetni_iznos << endl << n << endl;
	
		for(int i = 0; i < n; i++){
			int iznos = random_value(1000, 10000);
			tin << iznos << endl;
		}
	}
}
