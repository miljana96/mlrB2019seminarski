using System;
using System.Collections.Generic;

class Program
{
    struct krofna
    {
        public string naziv;
        public double cena;
    }
    static krofna[] unosNiza()
    {
        int n = int.Parse(Console.ReadLine());
        krofna[] krofne = new krofna[n];
        for (int i = 0; i < n; i++)
        {
            krofne[i].naziv = Console.ReadLine();
            krofne[i].cena = double.Parse(Console.ReadLine());
        }
        return krofne;
    }
    static void Main(string[] args)
    {
        double iznos = double.Parse(Console.ReadLine());
        krofna[] krofne = unosNiza();
        
		// sortriramo krofne prema ceni nerastuce 
		Array.Sort(krofne,
                   (krofna1, krofna2) => krofna2.cena.CompareTo(krofna1.cena));
        
		if(iznos >= krofne[0].cena){
			for (int i = 0; iznos > 0 && i < krofne.Length; i++) {
				if (iznos >= krofne[i].cena) {
					Console.WriteLine(krofne[i].naziv + " " + krofne[i].cena.ToString("0.00"));
					iznos -= krofne[i].cena;
				}
			}
		}else{
			Console.WriteLine("Iznos novca je manji od najskuplje krofne");
		}
		
        if (iznos > 0)
            Console.WriteLine(iznos.ToString("0.00"));
    }
}