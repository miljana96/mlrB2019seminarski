iznos = float(input())
n = int(input())
krofne = {}
niz_cena = []
for i in range(n):
    naziv = input()
    cena = float(input())
    krofne[cena]=naziv
    niz_cena.append(cena)

niz_cena.sort()
niz_cena.reverse()

if iznos >= niz_cena[0]:
	for i in range(n):
		if iznos > 0:
			if iznos >= niz_cena[i]:
				print(krofne[niz_cena[i]], end=" ");
				print("%.2f" %niz_cena[i])
				iznos -= niz_cena[i]
		else:
			break
else:
    print("Iznos novca je manji od najskuplje krofne")
	
if iznos > 0:
	print("%.2f" %iznos)