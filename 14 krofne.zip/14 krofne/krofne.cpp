#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

struct krofna {
  string naziv;
  double cena;
};

void ucitajPredmete(vector<krofna>& krofne) {
	int n;
	cin >> n;
	krofne.resize(n);
	for (int i = 0; i < n; i++) {
		cin >> krofne[i].naziv;
		cin >> krofne[i].cena;
	}
}

int main() {
	double iznos;
	cin >> iznos;
	
	vector<krofna> krofne;
	ucitajPredmete(krofne);
	sort(krofne.begin(), krofne.end(), [](const krofna& a, const krofna& b) {
		return a.cena > b.cena;
       });
	
	if(krofne[0].cena <= iznos){	
		for (int i = 0; iznos > 0 && i < krofne.size(); i++) {
			if (iznos >= krofne[i].cena) {
				cout << fixed << showpoint << setprecision(2) << krofne[i].naziv << " " << krofne[i].cena << endl;
				iznos -= krofne[i].cena;
			}
		}
	}else{
		cout << "Iznos novca je manji od najskuplje krofne" << endl;
	}
	
	if (iznos > 0)
		cout << fixed << showpoint << setprecision(2) <<iznos << endl;
  return 0;
}