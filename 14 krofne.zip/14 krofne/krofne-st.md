---
title: Крофне
timelimit: 1.0 # u sekundama
memlimit: 64   # u MB
owner: miljanamarkovic     # vlasnik je onaj ko radi na zadatku
origin:    # može ostati prazno, koristi se kada postoji potreba navodjena izvora
tags: []   # svaki zadatak treba ra je označen tagovima prema dogovorenoj listi tagova
status: KOMPLETAN   # jedan od: "IZRADA", "PREGLED", "KANDIDAT" ili "KOMPLETAN".
status-od:    # datum u formatu YYYY-MM-DD od kada je u navedenom statusu
solutions:
  - name: ex0
    lang: [cpp, cs]
    desc: ""
    tags: []
---

Свака крофна која је на продаји, има свој назив и цену. Мара жели да купи што скупље крофне новцем којим располаже. 
Купује крофне, почевши од најскупље, па све док има новца. Уколико нема новца за најскупљу, Мара неће купити ниједну крофну. 
Исписати називе крофни које Мара купује, и ако јој је остало, преостали износ новца.
Напомена: Све цене крофни су различите, као и називи крофни.

## Улаз

У провој линији стандардног улаза налази се износ новца (реалан број) који има Мара, у другој линији број предмета $n$,
a затим се, у сваке две линије стандардног улаза, уносе сe, редом, назив крофне, па цена (реалан број) крофне, свака у посебном реду, за свих $n$ крофни.

## Излаз

На стандардни излаз исписати списак крофни као и цена које је Мара купила у формату: назив крофне цена (вредност заокружити на две децимале).
Сваку крофну и цену, у посебној линији. Уколико је Мари преостало новца, исписати износ новца који јој је преостао (вредност заокружити на 2 децимале).
Уколико Мара нема новца за најскупљу крофну исписати поруку: "Iznos novca je manji od najskuplje krofne", као и износ новца који Мара поседује.

## Пример

### Улаз

~~~
1980
8
krofna0
110
krofna1
120
krofna2
130
krofna3
140
krofna4
150
krofna5
160
krofna6
170
krofna7
180
~~~

### Излаз

~~~
krofna7 180.00
krofna6 170.00
krofna5 160.00
krofna4 150.00
krofna3 140.00
krofna2 130.00
krofna1 120.00
krofna0 110.00
820.00
~~~
