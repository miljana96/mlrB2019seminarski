#include "tgen.hpp"
#include <string>
int rand_seed = 0;
int test_count = 10;
string naziv_zadatka = "krofne";

void gen_test(int i, ostream &tin) {
	
	double iznos = random_value(50,2000)*1.0;
	tin << iznos << endl;
	int n = random_value(1, 20);
	tin << n << endl;
	double cena = 100.00;
	for(int i = 0; i < n; i++)
	{
		tin << "krofna" << i << endl;
		cena += 10;
		tin << cena << endl;
	}
	
}
